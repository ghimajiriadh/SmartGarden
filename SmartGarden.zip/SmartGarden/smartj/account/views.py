from django.http import HttpResponse
from django.shortcuts import render
from django.contrib.auth import authenticate, login
from .forms import LoginForm,UserEditForm, ProfileEditForm
from .fusioncharts import FusionCharts
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Profile,tempo,Hum,HumSol,Arros
import time
from .mqttconn import arr
import paho.mqtt.client as paho
def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            user = authenticate(username=cd['username'],
            password=cd['password'])
            if user is not None:
                if user.is_active:
                    login(request, user)
                    return HttpResponse('Authenticated successfully')
            else:
                return HttpResponse('Disabled account')
        else:
                return HttpResponse('Invalid login')
    else:
        form = LoginForm()
    return render(request, 'account/login.html', {'form': form})
@login_required
def dashboard(request):

    d = tempo.objects.all()
    ds=Hum.objects.all()
    for m in d:
        l=m
    for m in ds:
        l1 = m

    return render(request,'account/dashboard.html',{'section': 'dashboard','tp':l.vals,'H':l1.vals})
@login_required
def fethi(request):
    return render(request,'account/fethi.html')
@login_required
def edit(request):
    if request.method == 'POST':
        user_form = UserEditForm(instance=request.user,data=request.POST)

        profile_form = ProfileEditForm(instance=request.user.profile,data=request.POST,files=request.FILES)
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(request,"profile updated :D ")
        else:
            messages.error(request,"error;")

    else:
        user_form = UserEditForm(instance=request.user)
        profile_form = ProfileEditForm(instance=request.user.profile)

    return render(request,
                  'account/edit.html',
                  {'user_form': user_form,
                      'profile_form': profile_form})
@login_required
def temperature(request):
    l=Profile.objects.filter(user_id=request.user.id)
    for m in l:
        d=tempo.objects.filter(profile_id=m.id)
    couple=[]
    data=[]
    for element in d :
        for_js = int(time.mktime(element.date.timetuple())) * 1000
        couple=[for_js,element.vals]
        data.append(couple)

    return render(request,'account/temperature.html',{'d':data})
@login_required
def humidity(request):
    l=Profile.objects.filter(user_id=request.user.id)
    for m in l:
        d=Hum.objects.filter(profile_id=m.id)
    couple=[]
    data=[]
    for element in d :
        for_js = int(time.mktime(element.date.timetuple())) * 1000
        couple=[for_js,element.vals]
        data.append(couple)

    return render(request,'account/humidity.html',{'d':data})
@login_required
def humiditySol(request):
    l=Profile.objects.filter(user_id=request.user.id)
    for m in l:
        d=HumSol.objects.filter(profile_id=m.id)
    couple=[]
    data=[]
    for element in d :
        for_js = int(time.mktime(element.date.timetuple())) * 1000
        couple=[for_js,element.vals]
        data.append(couple)

    return render(request,'account/humiditySol.html',{'d':data})
@login_required
def arroser(request):

    d = tempo.objects.all()
    ds=Hum.objects.all()
    for m in d:
        l=m
    for m in ds:
        l1 = m

    return render(request,'account/arrosage.html',{'d':l.vals,'h':l1.vals})
def arroser2(request):
    arr
    broker="127.0.0.1"
    port=1885
    client = paho.Client()
    client.connect(broker,port)
    client.publish("arroz",'1')
    d = tempo.objects.all()
    ds=Hum.objects.all()
    for m in d:
        l=m
    for m in ds:
        l1 = m

    return render(request,'account/arrosageDone.html',{'d':l.vals,'h':l1.vals,'s':"done"})