from django.contrib import admin
from .models import Profile,tempo,Hum,HumSol,Arros
# Register your models here.
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'date_of_birth', 'photo','number_capture')
admin.site.register(Profile, ProfileAdmin)
class TempoAdmin(admin.ModelAdmin):
    list_display = ('vals','capteurs')
admin.site.register(tempo,TempoAdmin)
class HumAdmin(admin.ModelAdmin):
    list_display = ('vals','capteurs')
admin.site.register(Hum,HumAdmin)
class ArrosAdmin(admin.ModelAdmin):
    list_display = ('date','duree')
admin.site.register(Arros,ArrosAdmin)
class HumSolAdmin(admin.ModelAdmin):
    list_display = ('vals','capteurs')
admin.site.register(HumSol,HumSolAdmin)