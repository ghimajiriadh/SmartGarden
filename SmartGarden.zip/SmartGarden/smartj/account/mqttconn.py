import paho.mqtt.client as paho
def arr():
    broker="127.0.0.1"
    port=1885
    client = paho.Client()
    client.connect(broker,port)
    client.publish("arroz",'1')