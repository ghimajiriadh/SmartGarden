
from django.db import models
import django.utils.timezone as tm
# Create your models here.
from django.conf import settings
class Profile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    date_of_birth = models.DateField(blank=True, null=True)
    photo = models.ImageField(upload_to='users/%Y/%m/%d',blank=True)
    number_capture= models.FloatField()

    def __str__(self):
        return 'Profile for user {}'.format(self.user.username)


class tempo(models.Model):
    profile = models.ForeignKey('Profile',on_delete=models.CASCADE, related_name='temp',default=1)
    vals = models.FloatField()
    capteurs = models.IntegerField()
    date=models.DateTimeField(default=tm.now())
class Hum(models.Model):
    profile = models.ForeignKey('Profile',on_delete=models.CASCADE, related_name='hum',default=1)
    vals = models.FloatField()
    capteurs = models.IntegerField()
    date=models.DateTimeField(default=tm.now())
class HumSol(models.Model):
    profile = models.ForeignKey('Profile',on_delete=models.CASCADE, related_name='humSol',default=1)
    vals = models.FloatField()
    capteurs = models.IntegerField()
    date=models.DateTimeField(default=tm.now())
class Arros(models.Model):
    profile = models.ForeignKey('Profile',on_delete=models.CASCADE, related_name='arros',default=1)
    duree = models.FloatField()

    date=models.DateTimeField(default=tm.now())