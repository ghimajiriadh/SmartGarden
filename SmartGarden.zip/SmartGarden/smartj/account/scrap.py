import re
from robobrowser import RoboBrowser
base_url='http://193.253.237.167:38080/loraclient'
browser = RoboBrowser(history=True, parser="html.parser")
browser.open(base_url)

form = browser.get_form(id='loginForm')

form["username"].value = 'supervision_Supcom@sagemcom.com'
form["password"].value = 'supervision_Supcom'
browser.session.headers['Referer'] = base_url

browser.submit_form(form)
#print(str(browser.select))
browser.open("http://193.253.237.167:38080/loraclient/endpointDownlink.html")
form1 = browser.get_form(id='formoid')

form1['appeui'].options.append('0101010101010101')
form1['appeui'].value='0101010101010101'

form1['deveui'].options.append('3434373170367B0E')
form1['deveui'].value='3434373170367B0E'

form1['devid'].options.append('ST007_447')
form1['devid'].value='ST007_447'


form1['expid'].value='10'


form1['fport'].value='2'


form1['payload'].value='ff11'

print(str(browser.select))
#browser.session.headers['Referer'] = "http://193.253.237.167:38080/loraclient/endpointDownlink.html"
#res = browser.submit_form(form, submit='NameOfTheButton')
res = browser.submit_form(form1)

form1.parsed()
print( res)


